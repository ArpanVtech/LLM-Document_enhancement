src/
├── routes/
│   ├── Document.py
│   └── __init__.py
├── agents/
│   ├── document_agents.py
│   └── __init__.py
├── tasks/
│   ├── document_tasks.py
│   └── __init__.py
├── crew/
│   ├── document_crew.py
│   └── __init__.py
├── text_extractors.py
├── demo_app.py
└── main.py
static/
└── index.html

///
##### 
This was build with help of crewAI 
